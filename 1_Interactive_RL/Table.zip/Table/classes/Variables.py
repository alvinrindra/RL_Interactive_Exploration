# -*- coding: utf-8 -*-
"""
Created on Mon Nov 9 12:40:33 2015

@author: cruz
"""

reward = 1
punishment = -1
feedbackstrategy_random = 0
feedbackstrategy_early = 1
feedbackstrategy_importance = 2
feedbackstrategy_correction = 3

# optimal mistake correcting importance threshold
importancethreshold =  0.01

# optimal importance advising threshhold
# importancethreshold =  0.02