# -*- coding: utf-8 -*-
"""
Created on Mon Nov 9 12:40:33 2015

@author: cruz
"""

reward = 1
punishment = -1
explorationstrat_epsgreedy = 0
explorationstrat_softmax = 1
explorationstrat_vdbe = 2
explorationstrat_vdbe_softmax = 3

learning_alg_qlearning = 0
learning_alg_sarsa = 1
